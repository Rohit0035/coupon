 <!-- Footer Part Start -->
 <footer class="cbx-footer">

<!-- Footer Top Part Start -->
<div class="cbx-footer-top">
    <div class="container">
        <div class="row">

            <div class="col-md-3 col-sm-6 col-xs-12">
                <!-- Footer widget about Part Start -->
                <div class="widget widget-about">
                    <div class="">
                        <a href="#">
                            <img src="assets/img/logo/logo-light.png" alt="" class="" width="100px"/>
                        </a>
                    </div>
                    <p>We coupon so to be  for the us me dose this recept good bad think nice beauti full thanks, moja los, u hungry naki food panda use sultan dine.</p>
                    <div class="widget-social">
                        <ul>
                            <li>
                                <a href="#">
                                    <i class="fa fa-facebook"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="fa fa-twitter"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="fa fa-linkedin"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="fa fa-vimeo"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Footer widget about Part End -->
            </div>

            <div class="col-md-2 col-sm-6 col-xs-12">
                <!-- Footer widget listings Part Start -->
                <div class="widget widget-listings">
                    <h2>Usefull Link</h2>
                    <ul>
                        <li>
                            <a href="aboutus.php">About us</a>
                        </li>

                        <li>
                            <a href="contact.php">Contact Us</a>
                        </li>

                        <li>
                            <a href="#"></a>
                        </li>

                        <li>
                            <a href="#">FAQ</a>
                        </li>

                        <li>
                            <a href="#">Support</a>
                        </li>
                    </ul>
                </div>
                <!-- Footer widget listings Part End -->
            </div>

            <div class="col-md-2 col-sm-6 col-xs-12">
                <!-- Footer widget widget-listings Part Start -->
                <div class="widget widget-listings">
                    <h2>FAQ</h2>
                    <ul>
                        <li>
                            <a href="#">Duis aute irure dolor?</a>
                        </li>

                        <li>
                            <a href="#">Sunt in culpa qui officia?</a>
                        </li>

                        <li>
                            <a href="#">Cillum dolore eu fugiat?</a>
                        </li>

                        <li>
                            <a href="#">Lorem Ipsum dolor sit?</a>
                        </li>

                        <li>
                            <a href="#">Dolor Sit Amet?</a>
                        </li>
                    </ul>



                </div>
                <!-- Footer widget widget-listings Part End -->
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
                <!-- Footer widget newsletter Part Start -->
                <div class="widget widget-newsletter">
                    <div class="widget-newsletter-area">
                        <p>It you want to connect with us please subcribe by your email.</p>
                        <h5>We Accept:</h5>
                        <ul class="payment-gateways">
                            <li><a href="#"><img src="assets/img/payment_gateway/amex.png" alt="amex" /></a></li>
                            <li><a href="#"><img src="assets/img/payment_gateway/mastercard.png" alt="mastercard" /></a></li>
                            <li><a href="#"><img src="assets/img/payment_gateway/paypal.png" alt="paypal" /></a></li>
                            <li><a href="#"><img src="assets/img/payment_gateway/visa.png" alt="visa" /></a></li>
                        </ul>
                    </div>
                </div>
                <!-- Footer widget newsletter Part End -->
            </div>
        </div>
    </div>
</div>
<!-- Footer Top Part End -->

<!-- Footer Bottom Part Start -->
<div class="cbx-footer-bottom">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="copyright text-center">
                    <p>© 2022 Copyright lorem. All Rights reserved.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Footer Bottom Part End -->


</footer>
<!-- Footer Part End -->

<!-- Scroll to Top Start -->
<a href="#" class="scrollToTop">
<i class="fa fa-arrow-up"></i>
</a>
<!-- Scroll to Top End -->


<!-- //SITE CONTENT END -->

</div>


<!-- Modal -->
<div id="coupon-code" class="modal fade" role="dialog">
<div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Special Flash Sale</h4>
        </div>
        <div class="modal-body">
            <div class="coupon-modal-content">
                <div class="row">
                    <div class="col-md-5 col-sm-5 col-xs-12">
                        <div class="single-coupon-thumb">
                            <img src="assets/img/deal/deal12.jpg" alt="Coupon" class="img-thumbnail img-responsive">
                        </div>
                    </div>
                    <div class="col-md-7 col-sm-7 col-xs-12">
                        <p>COPY THIS CODE AND USE AT CHECKOUT</p>
                        <div class="input-group">
                            <input type="text" class="form-control" autocomplete="off" readonly="" value="HFRESH10">
                            <div class="input-group-btn">
                                <button class="clipboard btn btn-default" data-clipboard-text="HFRESH10"><i class="fa fa-clipboard" aria-hidden="true"></i> Copy to Clipboard</button>
                            </div>
                        </div>
                        <a class="btn btn-brand pull-right" href="#">Go To Store</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <img src="assets/img/slider/mini_add.jpg" alt="Coupon" class="img-responsive">
        </div>
    </div>

</div>
</div>

<!-- Modal -->
<div id="coupon-printable" class="modal fade" role="dialog">
<div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Special Flash Sale</h4>
        </div>
        <div class="modal-body">
            <div class="coupon-modal-content">
                <div class="row">
                    <div class="col-md-5 col-sm-5 col-xs-12">
                        <div class="single-coupon-thumb">
                            <img src="assets/img/deal/deal12.jpg" alt="Coupon" class="img-thumbnail img-responsive">
                        </div>
                    </div>
                    <div class="col-md-7 col-sm-7 col-xs-12">
                        <p>PRINT THIS COUPON AND REDEEM IT IN-STORE</p>
                        <a class="btn btn-brand" href="#">Print Now</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <img src="assets/img/slider/mini_add.jpg" alt="Coupon" class="img-responsive">
        </div>
    </div>

</div>
</div>

<!-- Modal -->
<div id="coupon-deal" class="modal fade" role="dialog">
<div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Special Flash Sale</h4>
        </div>
        <div class="modal-body">
            <div class="coupon-modal-content">
                <div class="row">
                    <div class="col-md-5 col-sm-5 col-xs-12">
                        <div class="single-coupon-thumb">
                            <img src="assets/img/deal/deal12.jpg" alt="Coupon" class="img-thumbnail img-responsive">
                        </div>
                    </div>
                    <div class="col-md-7 col-sm-7 col-xs-12">
                        <p>DEAL ACTIVATED, NO COUPON CODE REQUIRED!</p>
                        <a class="btn btn-brand" href="#">Go To Store</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <img src="assets/img/slider/mini_add.jpg" alt="Coupon" class="img-responsive">
        </div>
    </div>

</div>
</div>



<!-- SITE SCRIPT  -->

<!-- jquery -->
<script src="assets/vendor/jquery/jquery-1.11.3.min.js"></script>

<!-- BOOTSTRAP JS -->
<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- if load google maps then load this api -->
<script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyChihC--Jb_QURoXd2MugyC53cDQjrV2MY"></script>

<!-- load if our contact form or email subscribe options is used -->
<script src="assets/vendor/validation/jquery.validate.js"></script>

<!--owl-->
<script src="assets/vendor/owl-carousel/dist/owl.carousel.min.js"></script>

<!-- clipboard.js -->
<script src="assets/vendor/clipboard.js/clipboard.min.js"></script>

<!-- flatpickr -->
<script src="assets/vendor/flatpickr/flatpickr.js"></script>

<!-- lity -->
<script src="assets/vendor/lity/lity.min.js"></script>

<!-- Bootstrap Slider -->
<script src="assets/vendor/bootstrap-slider/bootstrap-slider.min.js"></script>

<!-- switcher -->
<script id="switcherhandle" src="assets/switcher/switcher.js"></script>

<!-- THEME SCRIPT  -->
<script src="assets/js/theme.js"></script>

<!-- CUSTOM SCRIPT  -->
<script src="assets/js/custom.js"></script>

</body>

</html>
