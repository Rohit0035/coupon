
<!-- Header Part End -->

<?php include 'header.php';?>


<!-- Header Part End -->


             <main id="main"  class="content">
                        <div class="container">
                            <div class="row">
                                <div class="col-xs-12">
                                    <h2 class="section-heading">Blog Grid with Right Sidebar</h2>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="blog-item-wrapper">
                    <div class="single-blog-item">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="blog-thumb">
                                    <a href="singleblog.php">
                                        <img src="assets/img/blog/blog1.jpg" alt="Blog" class="img-responsive img-rounded"/>
                                    </a>

                                </div>
                                <div class="blog-content">
                                    <h4><a href="singleblog.php">Proper Way To Connect Multiple Device</a></h4>
                                    <div class="blog-tags">
                                        <ul>
                                            <li class="blog-author"><a href="#"><i class="fa fa-user" aria-hidden="true"></i>Adam Smith</a></li>
                                            <li class="blog-date"><a href="#"><i class="fa fa-clock-o" aria-hidden="true"></i>Jan. 15 2017</a></li>
                                        </ul>
                                    </div>
                                    <p>Lorem ipsum dolor sit amet, ridens eligendi an nec, his nostro dolorum splendide te Docendi intellegebat eu pro.Lorem ipsum dolor sit amet, ridens eligendi an nec, his nostro dolorum splendide te Docendi intellegebat eu pro.dolorum splendide te Docendi intellegebat eu pro.</p>
                                    <a class="btn btn-brand readmore"  href="singleblog.php">Read More</a>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="blog-thumb">
                                    <a href="singleblog.php">
                                        <img src="assets/img/blog/blog2.jpg" alt="Blog" class="img-responsive img-rounded"/>
                                    </a>

                                </div>
                                <div class="blog-content">
                                    <h4><a href="singleblog.php">Proper Way To Connect Multiple Device</a></h4>
                                    <div class="blog-tags">
                                        <ul>
                                            <li class="blog-author"><a href="#"><i class="fa fa-user" aria-hidden="true"></i>Adam Smith</a></li>
                                            <li class="blog-date"><a href="#"><i class="fa fa-clock-o" aria-hidden="true"></i>Jan. 15 2017</a></li>
                                        </ul>
                                    </div>
                                    <p>Lorem ipsum dolor sit amet, ridens eligendi an nec, his nostro dolorum splendide te Docendi intellegebat eu pro.Lorem ipsum dolor sit amet, ridens eligendi an nec, his nostro dolorum splendide te Docendi intellegebat eu pro.dolorum splendide te Docendi intellegebat eu pro.</p>
                                    <a class="btn btn-brand readmore"  href="singleblog.php">Read More</a>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="blog-thumb">
                                    <a href="singleblog.php">
                                        <img src="assets/img/blog/blog3.jpg" alt="Blog" class="img-responsive img-rounded"/>
                                    </a>

                                </div>
                                <div class="blog-content">
                                    <h4><a href="single-blog-layout-1.html">Proper Way To Connect Multiple Device</a></h4>
                                    <div class="blog-tags">
                                        <ul>
                                            <li class="blog-author"><a href="#"><i class="fa fa-user" aria-hidden="true"></i>Adam Smith</a></li>
                                            <li class="blog-date"><a href="#"><i class="fa fa-clock-o" aria-hidden="true"></i>Jan. 15 2017</a></li>
                                        </ul>
                                    </div>
                                    <p>Lorem ipsum dolor sit amet, ridens eligendi an nec, his nostro dolorum splendide te Docendi intellegebat eu pro.Lorem ipsum dolor sit amet, ridens eligendi an nec, his nostro dolorum splendide te Docendi intellegebat eu pro.dolorum splendide te Docendi intellegebat eu pro.</p>
                                    <a class="btn btn-brand readmore"  href="singleblog.php">Read More</a>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="blog-thumb">
                                    <a href="singleblog.php">
                                        <img src="assets/img/blog/blog4.jpg" alt="Blog" class="img-responsive img-rounded"/>
                                    </a>

                                </div>
                                <div class="blog-content">
                                    <h4><a href="singleblog.php">Proper Way To Connect Multiple Device</a></h4>
                                    <div class="blog-tags">
                                        <ul>
                                            <li class="blog-author"><a href="#"><i class="fa fa-user" aria-hidden="true"></i>Adam Smith</a></li>
                                            <li class="blog-date"><a href="#"><i class="fa fa-clock-o" aria-hidden="true"></i>Jan. 15 2017</a></li>
                                        </ul>
                                    </div>
                                    <p>Lorem ipsum dolor sit amet, ridens eligendi an nec, his nostro dolorum splendide te Docendi intellegebat eu pro.Lorem ipsum dolor sit amet, ridens eligendi an nec, his nostro dolorum splendide te Docendi intellegebat eu pro.dolorum splendide te Docendi intellegebat eu pro.</p>
                                    <a class="btn btn-brand readmore"  href="single-blog.html">Read More</a>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="blog-thumb">
                                    <a href="singleblog.php">
                                        <img src="assets/img/blog/blog5.jpg" alt="Blog" class="img-responsive img-rounded"/>
                                    </a>

                                </div>
                                <div class="blog-content">
                                    <h4><a href="singleblog.php">Proper Way To Connect Multiple Device</a></h4>
                                    <div class="blog-tags">
                                        <ul>
                                            <li class="blog-author"><a href="#"><i class="fa fa-user" aria-hidden="true"></i>Adam Smith</a></li>
                                            <li class="blog-date"><a href="#"><i class="fa fa-clock-o" aria-hidden="true"></i>Jan. 15 2017</a></li>
                                        </ul>
                                    </div>
                                    <p>Lorem ipsum dolor sit amet, ridens eligendi an nec, his nostro dolorum splendide te Docendi intellegebat eu pro.Lorem ipsum dolor sit amet, ridens eligendi an nec, his nostro dolorum splendide te Docendi intellegebat eu pro.dolorum splendide te Docendi intellegebat eu pro.</p>
                                    <a class="btn btn-brand readmore"  href="singleblog.php">Read More</a>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="blog-thumb">
                                    <a href="singleblog.php">
                                        <img src="assets/img/blog/blog6.jpg" alt="Blog" class="img-responsive img-rounded"/>
                                    </a>

                                </div>
                                <div class="blog-content">
                                    <h4><a href="singleblog.php">Proper Way To Connect Multiple Device</a></h4>
                                    <div class="blog-tags">
                                        <ul>
                                            <li class="blog-author"><a href="#"><i class="fa fa-user" aria-hidden="true"></i>Adam Smith</a></li>
                                            <li class="blog-date"><a href="#"><i class="fa fa-clock-o" aria-hidden="true"></i>Jan. 15 2017</a></li>
                                        </ul>
                                    </div>
                                    <p>Lorem ipsum dolor sit amet, ridens eligendi an nec, his nostro dolorum splendide te Docendi intellegebat eu pro.Lorem ipsum dolor sit amet, ridens eligendi an nec, his nostro dolorum splendide te Docendi intellegebat eu pro.dolorum splendide te Docendi intellegebat eu pro.</p>
                                    <a class="btn btn-brand readmore"  href="single-blog-layout-1.html">Read More</a>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="blog-thumb">
                                    <a href="single-blog-layout-1.html">
                                        <img src="assets/img/blog/blog7.jpg" alt="Blog" class="img-responsive img-rounded"/>
                                    </a>

                                </div>
                                <div class="blog-content">
                                    <h4><a href="single-blog-layout-1.html">Proper Way To Connect Multiple Device</a></h4>
                                    <div class="blog-tags">
                                        <ul>
                                            <li class="blog-author"><a href="#"><i class="fa fa-user" aria-hidden="true"></i>Adam Smith</a></li>
                                            <li class="blog-date"><a href="#"><i class="fa fa-clock-o" aria-hidden="true"></i>Jan. 15 2017</a></li>
                                        </ul>
                                    </div>
                                    <p>Lorem ipsum dolor sit amet, ridens eligendi an nec, his nostro dolorum splendide te Docendi intellegebat eu pro.Lorem ipsum dolor sit amet, ridens eligendi an nec, his nostro dolorum splendide te Docendi intellegebat eu pro.dolorum splendide te Docendi intellegebat eu pro.</p>
                                    <a class="btn btn-brand readmore"  href="single-blog-layout-1.html">Read More</a>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="blog-thumb">
                                    <a href="single-blog-layout-1.html">
                                        <img src="assets/img/blog/blog8.jpg" alt="Blog" class="img-responsive img-rounded"/>
                                    </a>

                                </div>
                                <div class="blog-content">
                                    <h4><a href="single-blog-layout-1.html">Proper Way To Connect Multiple Device</a></h4>
                                    <div class="blog-tags">
                                        <ul>
                                            <li class="blog-author"><a href="#"><i class="fa fa-user" aria-hidden="true"></i>Adam Smith</a></li>
                                            <li class="blog-date"><a href="#"><i class="fa fa-clock-o" aria-hidden="true"></i>Jan. 15 2017</a></li>
                                        </ul>
                                    </div>
                                    <p>Lorem ipsum dolor sit amet, ridens eligendi an nec, his nostro dolorum splendide te Docendi intellegebat eu pro.Lorem ipsum dolor sit amet, ridens eligendi an nec, his nostro dolorum splendide te Docendi intellegebat eu pro.dolorum splendide te Docendi intellegebat eu pro.</p>
                                    <a class="btn btn-brand readmore"  href="single-blog-layout-1.html">Read More</a>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="blog-thumb">
                                    <a href="single-blog-layout-1.html">
                                        <img src="assets/img/blog/blog9.jpg" alt="Blog" class="img-responsive img-rounded"/>
                                    </a>

                                </div>
                                <div class="blog-content">
                                    <h4><a href="single-blog-layout-1.html">Proper Way To Connect Multiple Device</a></h4>
                                    <div class="blog-tags">
                                        <ul>
                                            <li class="blog-author"><a href="#"><i class="fa fa-user" aria-hidden="true"></i>Adam Smith</a></li>
                                            <li class="blog-date"><a href="#"><i class="fa fa-clock-o" aria-hidden="true"></i>Jan. 15 2017</a></li>
                                        </ul>
                                    </div>
                                    <p>Lorem ipsum dolor sit amet, ridens eligendi an nec, his nostro dolorum splendide te Docendi intellegebat eu pro.Lorem ipsum dolor sit amet, ridens eligendi an nec, his nostro dolorum splendide te Docendi intellegebat eu pro.dolorum splendide te Docendi intellegebat eu pro.</p>
                                    <a class="btn btn-brand readmore"  href="single-blog-layout-1.html">Read More</a>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="blog-thumb">
                                    <a href="single-blog-layout-1.html">
                                        <img src="assets/img/blog/blog10.jpg" alt="Blog" class="img-responsive img-rounded"/>
                                    </a>

                                </div>
                                <div class="blog-content">
                                    <h4><a href="single-blog-layout-1.html">Proper Way To Connect Multiple Device</a></h4>
                                    <div class="blog-tags">
                                        <ul>
                                            <li class="blog-author"><a href="#"><i class="fa fa-user" aria-hidden="true"></i>Adam Smith</a></li>
                                            <li class="blog-date"><a href="#"><i class="fa fa-clock-o" aria-hidden="true"></i>Jan. 15 2017</a></li>
                                        </ul>
                                    </div>
                                    <p>Lorem ipsum dolor sit amet, ridens eligendi an nec, his nostro dolorum splendide te Docendi intellegebat eu pro.Lorem ipsum dolor sit amet, ridens eligendi an nec, his nostro dolorum splendide te Docendi intellegebat eu pro.dolorum splendide te Docendi intellegebat eu pro.</p>
                                    <a class="btn btn-brand readmore"  href="single-blog-layout-1.html">Read More</a>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>

                    <div class="pagination-wrapper">
                    <ul class="pagination">
                        <li class="disabled"><a href="#"><i class="fa fa-angle-left"></i>Previous</a></li>
                        <li class="active"><a href="#">1 <span class="sr-only">(current)</span></a></li>
                        <li><a href="#">2</a></li>
                        <li><a href="#">3</a></li>
                        <li><a href="#">4</a></li>
                        <li><a href="#">5</a></li>
                        <li><a href="#"> Next<i class="fa fa-angle-right"></i></a></li>
                    </ul>
                </div>
                </div>
                <div class="col-md-4">
                    <aside>
                    <div class="cbx-sidebar">
                        <div class="widget widget-search">
                            <h4 class="no-top-margin">Search</h4>

                            <div class="widget-content widget-content-search">
                                <form role="search" method="get" class="search-form">
                                    <span class="sr-only">Search for:</span>
                                    <input type="text" class="form-control" placeholder="Type keywords ...">
                                    <button type="submit">
                                        <i class="fa fa-search"></i>
                                        <span class="sr-only">Submit</span>
                                    </button>
                                </form>
                            </div>
                        </div>

                        <div class="widget widget-blog">
                            <h4>Latest Blog</h4>

                            <div class="widget-content widget-content-blog-list">
                                <div class="cbx-blog-list">
                                    <ul class="">
                                        <li>
                                            <div class="widget-content-single-blog">
                                                <div class="img-area">
                                                    <a target="_blank" title="Blog" href="single-blog-layout-1.html">
                                                        <img alt="blog" class="img-responsive img-rounded" src="assets/img/blog/blog1.jpg"/></a>
                                                </div>
                                                <div class="content-area">
                                                    <h4 class="title">
                                                        <a href="single-blog-layout-1.html">Cras porttitor convallis ligula</a>
                                                    </h4>
                                                    <a href="single-blog-layout-1.html">14 December 2016</a>
                                                </div>
                                            </div>
                                        </li>

                                        <li>
                                            <div class="widget-content-single-blog">
                                                <div class="img-area">
                                                    <a target="_blank" title="Blog" href="single-blog-layout-1.html">
                                                        <img alt="blog" class="img-responsive img-rounded" src="assets/img/blog/blog2.jpg"/></a>
                                                </div>
                                                <div class="content-area">
                                                    <h4 class="title">
                                                        <a href="single-blog-layout-1.html">Lorem ipsum dolor sit amet</a>
                                                    </h4>
                                                    <a href="single-blog-layout-1.html">14 November 2016</a>
                                                </div>
                                            </div>
                                        </li>

                                        <li>
                                            <div class="widget-content-single-blog">
                                                <div class="img-area">
                                                    <a target="_blank" title="Blog" href="single-blog-layout-1.html">
                                                        <img alt="blog" class="img-responsive img-rounded" src="assets/img/blog/blog3.jpg"/></a>
                                                </div>
                                                <div class="content-area">
                                                    <h4 class="title">
                                                        <a href="single-blog-layout-1.html">Docendi intellegebat eu pro</a>
                                                    </h4>
                                                    <a href="single-blog-layout-1.html">14 October 2016</a>
                                                </div>
                                            </div>
                                        </li>


                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="widget widget-blog">
                            <h4>Recent Updates</h4>

                            <div class="widget-content widget-content-blog-list">
                                <div class="cbx-blog-list">
                                    <ul class="">
                                        <li>
                                            <div class="widget-content-single-blog">
                                                <div class="img-area">
                                                    <a target="_blank" title="Blog" href="single-blog-layout-1.html">
                                                        <img alt="blog" class="img-responsive img-rounded" src="assets/img/blog/blog9.jpg"/></a>
                                                </div>
                                                <div class="content-area">
                                                    <h4 class="title">
                                                        <a href="single-blog-layout-1.html">Cras porttitor convallis ligula</a>
                                                    </h4>
                                                    <a href="single-blog-layout-1.html">14 December 2016</a>
                                                </div>
                                            </div>
                                        </li>

                                        <li>
                                            <div class="widget-content-single-blog">
                                                <div class="img-area">
                                                    <a target="_blank" title="Blog" href="single-blog-layout-1.html">
                                                        <img alt="blog" class="img-responsive img-rounded" src="assets/img/blog/blog10.jpg"/></a>
                                                </div>
                                                <div class="content-area">
                                                    <h4 class="title">
                                                        <a href="single-blog-layout-1.html">Lorem ipsum dolor sit amet</a>
                                                    </h4>
                                                    <a href="single-blog-layout-1.html">14 November 2016</a>
                                                </div>
                                            </div>
                                        </li>

                                        <li>
                                            <div class="widget-content-single-blog">
                                                <div class="img-area">
                                                    <a target="_blank" title="Blog" href="single-blog-layout-1.html">
                                                        <img alt="blog" class="img-responsive img-rounded" src="assets/img/blog/blog11.jpg"/></a>
                                                </div>
                                                <div class="content-area">
                                                    <h4 class="title">
                                                        <a href="single-blog-layout-1.html">Docendi intellegebat eu pro</a>
                                                    </h4>
                                                    <a href="single-blog-layout-1.html">14 October 2016</a>
                                                </div>
                                            </div>
                                        </li>


                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="widget widget-tags">
                            <h4 class="no-top-margin">Popular Tags</h4>

                            <div class="widget-content widget-content-tags">
                                <ul class="list-unstyled">
                                    <li><a href="#">Hello</a></li>
                                    <li><a href="#">World</a></li>
                                    <li><a href="#">Lorem</a></li>
                                    <li><a href="#">Ipsum</a></li>
                                    <li><a href="#">WordPress</a></li>
                                    <li><a href="#">Coupon</a></li>
                                </ul>
                            </div>
                        </div>

                        <div class="widget widget-category">
                            <h4 class="no-top-margin">Categories</h4>

                            <div class="widget-content widget-content-categories">
                                <ul class="list-unstyled">
                                    <li><a href="#">Tips & Tricks</a></li>
                                    <li><a href="#">Career Suggestion</a></li>
                                    <li><a href="#">Resume Writing</a></li>
                                    <li><a href="#">Interview Facts</a></li>
                                    <li><a href="#">Job Guideline</a></li>
                                    <li><a href="#">Good Practices</a></li>
                                    <li><a href="#">'Not to do's</a></li>
                                </ul>
                            </div>
                        </div>

                        <div class="widget widget-archive">
                            <h4 class="no-top-margin">Archives</h4>

                            <div class="widget-content widget-content-categories">
                                <ul class="list-unstyled">
                                    <li><a href="#">Tips & Tricks</a></li>
                                    <li><a href="#">Career Suggestion</a></li>
                                    <li><a href="#">Resume Writing</a></li>
                                    <li><a href="#">Interview Facts</a></li>
                                    <li><a href="#">Job Guideline</a></li>
                                    <li><a href="#">Good Practices</a></li>
                                    <li><a href="#">'Not to do's</a></li>
                                </ul>
                            </div>
                        </div>

                        <div class="widget widget-meta">
                            <h4 class="no-top-margin">Meta</h4>

                            <div class="widget-content widget-content-categories">
                                <ul class="list-unstyled">
                                    <li><a href="#">Log in</a></li>
                                    <li><a href="#">Entries RSS</a></li>
                                    <li><a href="#">Comments RSS</a></li>
                                </ul>
                            </div>
                        </div>

                    </div>
    <!--//.cbx-sidebar-->
                    </aside>
                </div>
            </div>
        </div>
    </main>

<!-- Footer Part Start -->

<?php include 'footer.php';?>

<!-- Footer Part Start -->
