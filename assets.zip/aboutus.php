

<!-- Header Part  -->

<?php include 'header.php';?>

<!-- Header Part End -->


    <!-- Get to know us section start -->
    <div class="get-to-know-us-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="get-to-know-us-video">
                        <img src="assets/img/video/video_bg.jpg" alt="Video" class="img-responsive img-rounded"/>
                        <a href="http://www.youtube.com/watch?v=XSGBVzeBUbk" data-lity><i class="fa fa-play"></i></a>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="get-to-know-us-content">
                        <h6>Get To know Us</h6>
                        <p>We are couponZ, deals and coupon site in the world, we are the best company in our field, you can easily find may more offer and discount cupons and deals that can be save your money, and made your mind full freash.</p>
                        <p>So I think We get support form you and yours friend and family , alwayes welcome to our website to get discount</p>
                        <a href="#" class="btn btn-brand">Read More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Get to know us section end -->

    <!-- How we works Start -->
<div class="how-we-works-wrapper">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <h2 class="section-heading">How We Works</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="single-how-we-works text-center">
                    <div class="how-we-works-thumb">
                    <img src="assets/img/how-we-works/coupon.png" alt="How We Works" class="img-responsive"/>
                    </div>
                    <h6>Get Discount By Coupon</h6>
                    <p>You can get ma many discount wi coupon code apply of varius typeweb</p>
                    <a href="#" class="btn btn-brand">Get This</a>
                </div>
            </div>

            <div class="col-md-4">
                <div class="single-how-we-works text-center">
                    <div class="how-we-works-thumb">
                    <img src="assets/img/how-we-works/deal.png" alt="How We Works" class="img-responsive"/>
                    </div>
                    <h6>Get Discount By Deal</h6>
                    <p>You can get ma many discount wi coupon code apply of varius typeweb</p>
                    <a href="#" class="btn btn-brand">Get This</a>
                </div>
            </div>

            <div class="col-md-4">
                <div class="single-how-we-works text-center">
                    <div class="how-we-works-thumb">
                    <img src="assets/img/how-we-works/voucher.png" alt="How We Works" class="img-responsive"/>
                    </div>
                    <h6>Gift Cash Voucher</h6>
                    <p>You can get ma many discount wi coupon code apply of varius typeweb</p>
                    <a href="#" class="btn btn-brand">Get This</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- How we works End -->

    <!-- Team Start -->
<div class="team-wrapper">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <h2 class="section-heading">Our Team</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="single-team">
                    <div class="team-thumb-social-wrapper">
                        <img src="assets/img/team/team1.jpg" alt="" class="img-responsive"/>
                        <div class="team-social-profile">
                            <ul>
                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                <li><a href="#"><i class="fa fa-google"></i></a></li>
                                <li><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="team-profile">
                        <h6>Desmond Eagle</h6>
                        <p>Developer, at BDS</p>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="single-team">
                    <div class="team-thumb-social-wrapper">
                    <img src="assets/img/team/team2.jpg" alt="" class="img-responsive"/>
                    <div class="team-social-profile">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-google"></i></a></li>
                            <li><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
                        </ul>
                    </div>
                    </div>
                    <div class="team-profile">
                        <h6>Desmond Eagle</h6>
                        <p>Developer, at BDS</p>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="single-team">
                    <div class="team-thumb-social-wrapper">
                    <img src="assets/img/team/team3.jpg" alt="" class="img-responsive"/>
                    <div class="team-social-profile">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-google"></i></a></li>
                            <li><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
                        </ul>
                    </div>
                    </div>
                    <div class="team-profile">
                        <h6>Desmond Eagle</h6>
                        <p>Developer, at BDS</p>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="single-team">
                    <div class="team-thumb-social-wrapper">
                    <img src="assets/img/team/team4.jpg" alt="" class="img-responsive"/>
                    <div class="team-social-profile">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-google"></i></a></li>
                            <li><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
                        </ul>
                    </div>
                    </div>
                    <div class="team-profile">
                        <h6>Desmond Eagle</h6>
                        <p>Developer, at BDS</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Team End -->

<!-- Call to action start -->

<div class="call-to-action-wrapper">

    <div class="container">

        <div class="row">

            <div class="col-xs-12">

                <div class="call-to-action-content">
                    <p>Download <a href="#">CouponZ</a> Apps For <br>
                        Get Coupon Everywhere!</p>
                </div>

            </div>

        </div>

        <div class="row">

            <div class="col-xs-12">

                <div class="call-to-action-button text-center">

                    <ul>

                        <li class="apple-store">
                            <a href="#">
                                <i class="fa fa-apple"></i>
                                <div class="cta-btn-content">
                                    Download <span>From App Store</span>
                                </div>
                            </a>
                        </li>
                        <li class="google-play">
                            <a href="#">
                                <i class="fa fa-android"></i>
                                <div class="cta-btn-content">
                                    Download <span>From Play Store</span>
                                </div>
                            </a>
                        </li>

                    </ul>

                </div>

            </div>

        </div>

    </div>

</div>

<!-- Call to action end -->

<!-- Footer Part Start -->

<?php include 'footer.php';?>

<!-- Footer Part close -->
